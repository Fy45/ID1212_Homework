/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adroidhangmanserver;

/**
 *
 * @author user
 */
import java.net.*;
import java.util.ArrayList;
public class Adroidhangmanserver {

    /**
     * @param args the command line arguments
     */
  public static void main(String[] args) throws Exception{
        ArrayList<Socket> list = new ArrayList<Socket>();
        ServerSocket server = new ServerSocket(9999);
        while(true){
            System.out.println("start listening port 9999.");
            Socket socket=server.accept();
            list.add(socket);
            String hostname=socket.getInetAddress().getHostAddress();
            System.out.println(hostname+" is connected to server");
            new MultiThread(socket).start();
                    }
            
        }
    
}
