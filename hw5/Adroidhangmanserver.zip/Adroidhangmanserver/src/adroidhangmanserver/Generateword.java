/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adroidhangmanserver;

/**
 *
 * @author user
 */
public class Generateword {
     char [] Word;
     String Blank;
     int lifetime;
    int RestBlank;
    public void getWord() throws Exception{
        try{
        
        int R = (int)(Math.random() *7);//generate random number
        String[] Workspace={"java","lida","kth","kista","ict","programme","hello"};
        //String NEWWORD=NEW.WORD;
        String NEWWORD=Workspace[R];
       lifetime = NEWWORD.length();
       char [] blank=new char [lifetime];
	 Word=new char [lifetime];//将字符串数组中成员强行转换成为字符数组
	 Word=NEWWORD.toCharArray();
	 RestBlank=lifetime;
	for(int i=0;i<lifetime;i++) {
		blank[i]='*';}
        Blank=new String(blank,0,blank.length);
	//System.out.println("word to guess: "+String.valueOf(Blank));
        }catch(Exception e){
            
        }
}
}
