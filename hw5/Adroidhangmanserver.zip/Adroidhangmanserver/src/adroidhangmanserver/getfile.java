/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adroidhangmanserver;

/**
 *
 * @author user
 */
import java.io.*;
public class getfile {
    String WORD=new String();
    String [] Wordbase=new String [65535];
    String [] WORDbase;

    
        FileReader file = new FileReader("words.txt");
    
      getfile(int n) throws IOException{
        
		char[] buf=new char[65535];
		int num;
		String ss=new String();
		while((num=file.read(buf))!=-1)
		{
			ss=ss+new String(buf,0,num);
		}
                
               Wordbase=ss.split("\n");
              WORD=Wordbase[n];
    }
    
    
   
    
}
