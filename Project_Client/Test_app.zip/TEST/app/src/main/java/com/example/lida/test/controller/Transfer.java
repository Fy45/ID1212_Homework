package com.example.lida.test.controller;

import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.lida.test.R;
import com.example.lida.test.model.StringCut;
import com.example.lida.test.net.ClientThread;

public class Transfer extends AppCompatActivity {

    private Button okButton;
    private EditText othercard;
    private EditText amount;
    private EditText username;
    private ClientThread mclientThread;
    private Handler mHandler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);
        okButton = ((Button) findViewById(R.id.button));
        othercard=findViewById(R.id.editText);
        amount=findViewById(R.id.editText2);
        username=findViewById(R.id.editText4);
        mHandler=new Handler() {

            @Override
            public void handleMessage(Message msg) {
                if (msg.what == 0) {
                    String Receive=msg.obj.toString();//当接收到的信息是来自于登录的时候，就可以判断登陆是否成功
                    String operation= StringCut.getCTX(Receive,"[","]");
                    if(operation.equals("transfer")) {

                        OperationFeedback.feedback1 = StringCut.getCTX(Receive, "(", "*");
                        System.out.println(OperationFeedback.feedback1);
                    }
                }
                    Intent intent =new Intent(Transfer.this,OperationFeedback.class);
                    startActivity(intent);


            }
        };
        okButton.setEnabled(true);
        okButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)  {
                try {
                    Message msg=new Message();
                    msg.what=1;

                    msg.obj="[operation]"+"<"+"transfer"+":"+"*"+othercard.getText()+"$"+username.getText()+"/"+amount.getText().toString()+">";
                    System.out.println("send: "+msg.obj.toString());
                    mclientThread.revHandler.sendMessage(msg);
                    System.out.println("Begin to send msg");
                    othercard.setText("");
                    amount.setText("");
                    username.setText("");

                }catch(Exception e){
                    e.printStackTrace();
                }
            }
        });
        mclientThread = new ClientThread(mHandler);
        new Thread(mclientThread).start();
    }
}
