package com.example.lida.test.controller;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.lida.test.R;

public class MainOperationSelect extends AppCompatActivity {

    private Button quitButton;
    private Button transferButton;
    private Button depositButton;
    private Button withdrawButton;
    private Button investButton;
    private TextView user;
    private TextView Type;
    private TextView Debt;
    public static String usename;
    public static String type;
    public static String debt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        user=findViewById(R.id.textView6);
        Type=findViewById(R.id.textView10);
        Debt=findViewById(R.id.textView8);
        user.append(usename);
        Type.append(type);
        Debt.append(debt);
        quitButton = ((Button) findViewById(R.id.button5));
        quitButton.setEnabled(true);
        quitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)  {
                try {
                    
                    Intent intent =new Intent(MainOperationSelect.this,UserLogin.class);
                    startActivity(intent);

                }catch(Exception e){
                    e.printStackTrace();
                }
            }
        });
        transferButton = ((Button) findViewById(R.id.button));
        transferButton.setEnabled(true);
        transferButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)  {
                try {

                    Intent intent =new Intent(MainOperationSelect.this,Transfer.class);
                    startActivity(intent);

                }catch(Exception e){
                    e.printStackTrace();
                }
            }
        });
        withdrawButton= ((Button) findViewById(R.id.button2));
        withdrawButton.setEnabled(true);
        withdrawButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)  {
                try {

                    Intent intent =new Intent(MainOperationSelect.this,Withdraw.class);
                    startActivity(intent);

                }catch(Exception e){
                    e.printStackTrace();
                }
            }
        });
        depositButton= ((Button) findViewById(R.id.button3));
        depositButton.setEnabled(true);
        depositButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)  {
                try {

                    Intent intent =new Intent(MainOperationSelect.this,Deposit.class);
                    startActivity(intent);

                }catch(Exception e){
                    e.printStackTrace();
                }
            }
        });
        investButton = ((Button) findViewById(R.id.button4));
        investButton.setEnabled(true);
        investButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)  {
                try {

                    Intent intent =new Intent(MainOperationSelect.this,Invest.class);
                    startActivity(intent);

                }catch(Exception e){
                    e.printStackTrace();
                }
            }
        });
    }
}
