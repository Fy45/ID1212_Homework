package com.example.lida.test.controller;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.lida.test.R;
import com.example.lida.test.model.StringCut;

public class OperationFeedback extends AppCompatActivity {

    private Button quitButton;
    private Button backButton;
    public static String feedback1;
    private String successflag;
    private String feedback2;
    private TextView show;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        successflag="Fail";
        feedback2= StringCut.getCTX(feedback1,"<","!");
        successflag= StringCut.getCTX(feedback1,"<",">");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main9);
        show=findViewById(R.id.textView14);
        quitButton = ((Button) findViewById(R.id.button8));
        quitButton.setEnabled(true);
        show.append(feedback2);
        System.out.println(feedback1);
        quitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)  {
                try {

                    Intent intent =new Intent(OperationFeedback.this,UserLogin.class);
                    startActivity(intent);

                }catch(Exception e){
                    e.printStackTrace();
                }
            }
        });
        backButton = ((Button) findViewById(R.id.button7));
        backButton.setEnabled(true);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)  {
                try {
                    if(successflag.equals("Success")){
                        MainOperationSelect.usename= StringCut.getCTX(feedback1,"!","@");
                        MainOperationSelect.type= StringCut.getCTX(feedback1,"@","&");
                        MainOperationSelect.debt= StringCut.getCTX(feedback1,"&","");
                    }
                    Intent intent =new Intent(OperationFeedback.this,MainOperationSelect.class);
                    startActivity(intent);

                }catch(Exception e){
                    e.printStackTrace();
                }
            }
        });
    }
}
