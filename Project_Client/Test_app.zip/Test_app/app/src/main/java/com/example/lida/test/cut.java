package com.example.lida.test;

/**
 * Created by Lida on 2018/1/5.
 */

public class cut {
    public static String getCTX(String originalCTX, String firstSplit, String secondSplit)
    {
        String resultCTX = originalCTX.substring(originalCTX.lastIndexOf(firstSplit),
                originalCTX.lastIndexOf(secondSplit));
        resultCTX = resultCTX.substring(1,resultCTX.length());
        return resultCTX;
    }
}
