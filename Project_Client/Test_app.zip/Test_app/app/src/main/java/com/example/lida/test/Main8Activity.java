package com.example.lida.test;

import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Main8Activity extends AppCompatActivity {

    private Button okButton;
    private ClientThread mclientThread;
    private Handler mHandler;
    private EditText amount;
    private EditText invest;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main8);
        okButton = ((Button) findViewById(R.id.button6));
        amount=findViewById(R.id.editText5);
        invest=findViewById(R.id.editText6);
        mHandler=new Handler() {

            @Override
            public void handleMessage(Message msg) {
                if (msg.what == 0) {
                    String Receive=msg.obj.toString();//当接收到的信息是来自于登录的时候，就可以判断登陆是否成功
                    String operation=cut.getCTX(Receive,"[","]");
                    if(operation.equals("invest")) {

                        Main9Activity.feedback1 = cut.getCTX(Receive, "(", "*");
                    }
                }
                Intent intent =new Intent(Main8Activity.this,Main9Activity.class);
                startActivity(intent);


            }
        };
        okButton.setEnabled(true);
        okButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)  {
                try {

                    Message msg=new Message();
                    msg.what=1;

                    msg.obj="[operation]"+"<"+"invest"+":"+amount.getText().toString()+">"+invest.getText().toString()+"*";
                    System.out.println("send: "+msg.obj.toString());
                    mclientThread.revHandler.sendMessage(msg);
                    System.out.println("Begin to send msg");
                    amount.setText("");

                }catch(Exception e){
                    e.printStackTrace();
                }
            }
        });
        mclientThread = new ClientThread(mHandler);
        new Thread(mclientThread).start();
    }
}
