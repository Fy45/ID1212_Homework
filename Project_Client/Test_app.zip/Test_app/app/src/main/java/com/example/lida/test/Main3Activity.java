package com.example.lida.test;

import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;

public class Main3Activity extends AppCompatActivity {

    private Button RegisterButton;
    private ClientThread mclientThread;
    private EditText user;
    private EditText password;
    private EditText username;
    private CheckBox type;
    private Handler mHandler;
    private String achievement;
    //public static String feedback1;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        user=findViewById(R.id.editText);
        password=findViewById(R.id.editText2);
        username=findViewById(R.id.editText3);
        type=findViewById(R.id.checkBox);

        RegisterButton = ((Button) findViewById(R.id.button));
        mHandler=new Handler() {

            @Override
            public void handleMessage(Message msg) {
                if (msg.what == 0) {
                    String Receive=msg.obj.toString();//当接收到的信息是来自于登录的时候，就可以判断登陆是否成功
                    String operation=cut.getCTX(Receive,"[","]");
                    if(operation.equals("register")) {
                        achievement = cut.getCTX(Receive, "<", ">");
                        Main10Activity.feedback = cut.getCTX(Receive, "(", ")");
                    }
                }

                if(achievement.equals("Success")){
                    Intent intent =new Intent(Main3Activity.this,Main4Activity.class);
                    Main4Activity.usename=cut.getCTX(Main10Activity.feedback,"!","@");
                    Main4Activity.type=cut.getCTX(Main10Activity.feedback,"@","&");
                    Main4Activity.debt=cut.getCTX(Main10Activity.feedback,"&","*");
                    startActivity(intent);}
                else if(achievement.equals("Fail")){
                    Intent intent =new Intent(Main3Activity.this,Main10Activity.class);
                    startActivity(intent);}

            }
        };

        RegisterButton.setEnabled(true);
        RegisterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)  {
                try {

                    Message msg=new Message();
                    msg.what=1;
                    if(type.isChecked()){
                    msg.obj="["+"register"+"]"+"@"+user.getText()+"~"+password.getText()+"?"+username.getText().toString()+"#"+"credit"+"%";}
                    else{msg.obj="["+"register"+"]"+"@"+user.getText()+"~"+password.getText()+"?"+username.getText().toString()+"#"+"debt"+"%";}
                    System.out.println("send: "+msg.obj.toString());
                    mclientThread.revHandler.sendMessage(msg);
                    System.out.println("Begin to send msg");
                    user.setText("");
                    password.setText("");
                    username.setText("");
                    type.setChecked(false);

                }catch(Exception e){
                    e.printStackTrace();
                }
            }
        });

        mclientThread = new ClientThread(mHandler);
        new Thread(mclientThread).start();
    }
}
