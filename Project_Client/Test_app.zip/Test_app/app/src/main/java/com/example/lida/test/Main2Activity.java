package com.example.lida.test;

import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {
        private Button LoginButton;
        private Button RegisterButton;
        private ClientThread mclientThread;
        private Handler mHandler;
        private EditText user;
        private EditText password;
        private TextView loginresult;
        private String achievement;
        //public static String feedback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);


        LoginButton = ((Button) findViewById(R.id.loginButton));
        RegisterButton = ((Button) findViewById(R.id.button3));
        user=findViewById(R.id.user);
        password=findViewById(R.id.pass);
        loginresult=findViewById(R.id.resulttext);


        mHandler=new Handler() {

            @Override
            public void handleMessage(Message msg) {
                if (msg.what == 0) {
                    String Receive=msg.obj.toString();//当接收到的信息是来自于登录的时候，就可以判断登陆是否成功
                    String operation=cut.getCTX(Receive,"[","]");
                    if(operation.equals("login")) {
                        achievement = cut.getCTX(Receive, "<", ">");
                        Main10Activity.feedback = cut.getCTX(Receive, "(", ")");
                    }
                }

                if(achievement.equals("Success")){
                    Intent intent =new Intent(Main2Activity.this,Main4Activity.class);
                    Main4Activity.usename=cut.getCTX(Main10Activity.feedback,"!","@");
                    Main4Activity.type=cut.getCTX(Main10Activity.feedback,"@","&");
                    Main4Activity.debt=cut.getCTX(Main10Activity.feedback,"&","*");
                    startActivity(intent);}
                else if(achievement.equals("Fail")){
                    Intent intent =new Intent(Main2Activity.this,Main10Activity.class);
                    startActivity(intent);}

                }
        };


        LoginButton.setEnabled(true);
        LoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)  {
                try {
                    Message msg=new Message();
                    msg.what=1;
                    msg.obj="["+"login"+"]"+"@"+user.getText()+"~"+password.getText()+"?";
                    mclientThread.revHandler.sendMessage(msg);
                    System.out.println("Begin to send msg");
                    user.setText("");
                    password.setText("");
                }catch(Exception e){
                    e.printStackTrace();
                }
            }
        });


        RegisterButton.setEnabled(true);
        RegisterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)  {
                try {

                    Intent intent =new Intent(Main2Activity.this,Main3Activity.class);
                    startActivity(intent);

                }catch(Exception e){
                    e.printStackTrace();
                }
            }
        });


        mclientThread = new ClientThread(mHandler);
        new Thread(mclientThread).start();
    }

}
