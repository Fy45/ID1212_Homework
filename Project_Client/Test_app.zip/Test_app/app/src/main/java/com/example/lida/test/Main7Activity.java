package com.example.lida.test;

import android.content.Intent;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Main7Activity extends AppCompatActivity {

    private Button okButton;
    private ClientThread mclientThread;
    private Handler mHandler;
    private EditText amount;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main7);
        okButton = ((Button) findViewById(R.id.button));
        amount=findViewById(R.id.editText);
        mHandler=new Handler() {

            @Override
            public void handleMessage(Message msg) {
                if (msg.what == 0) {
                    String Receive=msg.obj.toString();//当接收到的信息是来自于登录的时候，就可以判断登陆是否成功
                    String operation=cut.getCTX(Receive,"[","]");
                    if(operation.equals("deposit")) {

                        Main9Activity.feedback1 = cut.getCTX(Receive, "(", "*");
                    }
                }
                Intent intent =new Intent(Main7Activity.this,Main9Activity.class);
                startActivity(intent);


            }
        };
        okButton.setEnabled(true);
        okButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view)  {
                try{

                    Message msg=new Message();
                    msg.what=1;

                    msg.obj="[operation]"+"<"+"deposit"+":"+amount.getText().toString()+">";
                    System.out.println("send: "+msg.obj.toString());
                    mclientThread.revHandler.sendMessage(msg);
                    System.out.println("Begin to send msg");
                    amount.setText("");

                }catch(Exception e){
                    e.printStackTrace();
                }
            }
        });
        mclientThread = new ClientThread(mHandler);
        new Thread(mclientThread).start();
    }
}
